public interface Term {

	public boolean isOperand();

	public String toString();

}