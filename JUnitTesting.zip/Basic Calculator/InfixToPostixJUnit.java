import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class InfixToPostixJUnit {

	static InfixToPostfix infixToPostfix = new InfixToPostfix();
	
	//Defined by each error message, this test method covers addition
	@Test
	public void addition() throws Exception{		
		assertEquals("Integer addition failed", "93.0", infixToPostfix.calculate("5+88"));
		assertEquals("Decimal addition failed", "17.4", infixToPostfix.calculate("6.3+11.1"));
		assertEquals("Mixed addition failed", "67.8", infixToPostfix.calculate("55+12.8"));
		assertEquals("Negative addition failed", "12.0", infixToPostfix.calculate("15+-3"));
		assertEquals("Negative addition answer failed", "-6.0", infixToPostfix.calculate("-9+3"));
		assertEquals("Large addition failed", "9.00009E13", infixToPostfix.calculate("900000000+90000000000000"));
	}

	//Defined by each error message, this test method covers subtraction
	@Test
	public void subtraction() throws Exception{
		assertEquals("Integer Subtraction failed", "94.0", infixToPostfix.calculate("99-5"));
		assertEquals("Decimal Subtraction failed", "63.4", infixToPostfix.calculate("65.5-2.1"));
		assertEquals("Mixed Subtraction failed", "12.8", infixToPostfix.calculate("18.8-6"));
		assertEquals("Negative Subtraction failed", "46.0", infixToPostfix.calculate("45--1"));
		assertEquals("Negative Subtraction answer failed", "-25.0", infixToPostfix.calculate("-19-6"));
		assertEquals("Large subtraction failed", "9.999999999E9", infixToPostfix.calculate("10000000000-1"));
		assertEquals("Large subtraction failed", "-1.0E13", infixToPostfix.calculate("0-10000000000000"));
	}

	//Defined by each error message, this test method covers multiplication
	@Test
	public void multiplication() throws Exception{
		assertEquals("Integer multiplication failed", "20.0", infixToPostfix.calculate("5*4"));
		assertEquals("Decimal multiplication failed", "33.55", infixToPostfix.calculate("5.5*6.1"));
		assertEquals("Mixed multiplication failed", "-46.8", infixToPostfix.calculate("12*-3.9"));
		assertEquals("Negative multiplication answer failed", "-117.0", infixToPostfix.calculate("-9*13"));
		assertEquals("Large multiplication failed", "1.0E12", infixToPostfix.calculate("100000000*10000"));
	}

	//Defined by each error message, this test method covers division
	@Test
	public void division() throws Exception{
		assertEquals("Whole Integer division failed", "3.0", infixToPostfix.calculate("18/6"));
		assertEquals("Integer division failed", "6.5", infixToPostfix.calculate("26/4"));
		assertEquals("Decimal division failed", "1.0", infixToPostfix.calculate("5.5/5.5"));
		assertEquals("Mixed division failed", "6.055", infixToPostfix.calculate("24.22/4"));
		assertEquals("Negative division answer failed", "-5.0", infixToPostfix.calculate("30/-6"));
		assertEquals("Large division failed", "2.5E13", infixToPostfix.calculate("50000000000000/2"));
	}

	//Defined by each error message, this test method covers order of operations
	@Test
	public void pemdas() throws Exception{
		assertEquals("PEMDAS check 1 failed", "8.0", infixToPostfix.calculate("5+12-9"));
		assertEquals("PEMDAS check 2 failed", "33.0", infixToPostfix.calculate("66*2/4"));
		assertEquals("PEMDAS check 3 failed", "27.0", infixToPostfix.calculate("45-6*3"));
		assertEquals("PEMDAS check 4 failed", "31.0", infixToPostfix.calculate("12+12/2+13"));
	}

	//Defined by each error message, this test method covers the use of parenthesis
	@Test
	public void parenthesis() throws Exception{
		assertEquals("Parenthesis check 1 failed", "24.0", infixToPostfix.calculate("4*(9-3)"));
		assertEquals("Parenthesis check 2 failed", "9.0", infixToPostfix.calculate("((9))"));
		assertEquals("Parenthesis check 3 failed", "-25.5", infixToPostfix.calculate("33-15/(3*2)-56"));
		assertEquals("Parenthesis check 4 failed", "-99.0", infixToPostfix.calculate("(5-4-(6*2))*9"));
		
	}

	//Defined by each error message, this test method covers the use of a variable
	@Test
	public void variableX() throws Exception{
		assertEquals("Set variable 1 failed", "3.0", infixToPostfix.calculate("x=3"));
		assertEquals("Set variable 2 failed", "14.0", infixToPostfix.calculate("x = 7*2"));
		assertEquals("Save variable failed", "14.0", infixToPostfix.calculate("x"));
		assertEquals("Use variable failed", "24.0", infixToPostfix.calculate("x + 10"));
		assertEquals("Negative variable failed", "-12.0", infixToPostfix.calculate("x = -12"));
		assertEquals("Use negative variable failed", "-10.0", infixToPostfix.calculate("x + 2"));
		assertEquals("Decimal variable failed", "22.2", infixToPostfix.calculate("x = 22.2"));
		assertEquals("Use decimal variable failed", "66.6", infixToPostfix.calculate("x *3"));
	}

	//Defined by each error message, this test method continues to cover variables
	@Test
	public void multipleVariables() throws Exception{
		assertEquals("Use illegal variable failed", ".12345", infixToPostfix.calculate("y + 8"));
		assertEquals("Set 'y' variable failed", "8.0", infixToPostfix.calculate("y=8"));
		assertEquals("Use 'y' variable failed", "12.0", infixToPostfix.calculate("y+4"));
		assertEquals("Set 'z' variable failed", "100.0", infixToPostfix.calculate("z=100"));
		assertEquals("Use 'z' variable failed", "10.0", infixToPostfix.calculate("z/10"));
		assertEquals("Set using variables failed", "6.0", infixToPostfix.calculate("x = y-2"));
		assertEquals("Use multiple variables failed", "94.0", infixToPostfix.calculate("z - x"));
	}

	//Defined by each error message, this test method covers error cases
	@Test
	public void error() throws Exception{
		assertEquals("Illegal symbol failed", ".12345", infixToPostfix.calculate("45#2"));
		assertEquals("Missing number failed", ".12345", infixToPostfix.calculate("*9"));
		assertEquals("Missing symbol failed", ".12345", infixToPostfix.calculate("8(9)"));
		assertEquals("Extra symbol failed", ".12345", infixToPostfix.calculate("5+*5"));
		assertEquals("Extra left paren failed", ".12345", infixToPostfix.calculate("8+9("));
		assertEquals("Extra right paren failed", ".12345", infixToPostfix.calculate("8+9)"));
		assertEquals("Divide by 0 failed", "Infinity", infixToPostfix.calculate("50/0"));
	}

	//Defined by each error message, this test method covers various formats for entering legal expressions
	@Test
	public void Layout() throws Exception{
		assertEquals("Layout check 1 failed", "45.0", infixToPostfix.calculate("     9* 5  "));
		assertEquals("Layout check 2 failed", "6.0", infixToPostfix.calculate("9  -  3"));
		assertEquals("Single decimal", "4.5", infixToPostfix.calculate("9*.5"));
		assertEquals("Double negative", "12.0", infixToPostfix.calculate("10--2"));
		assertEquals("Double positive", "16.0", infixToPostfix.calculate("12++4"));
	}
}
