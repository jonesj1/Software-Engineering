import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class Tester 
{
	@Rule
	 public final ExpectedException exception = ExpectedException.none();
	
	public void setUp()
	{
		
	}
	@Test
	public void testMain() 
	{
		testExpressionNodes();
		testParser();
		testSetVariable();
		testSolution();
		testParserException();
		testEvaluationException();
	}
	
	
	@Test
	public void testExpressionNodes() 
	{
		assertTrue(Main.compareNodeType("x",1));
		assertTrue(Main.compareNodeType("5",2));
		assertTrue(Main.compareNodeType("3+5",3));
		assertTrue(Main.compareNodeType("3*5",4));
		assertTrue(Main.compareNodeType("3^5",5));
		assertTrue(Main.compareNodeType("x^2",5));
		
		assertFalse(Main.compareNodeType("x^2", 1));
		assertFalse(Main.compareNodeType("2", 3));
		assertFalse(Main.compareNodeType("3*5", 5));
	}
	
	@Test
	public void testParser()
	{
		int[] tokens = {7,1,7};
		assertTrue(Main.checkTokens("1+1", tokens));
		int[] tokens2 = {7,3,7};
		assertTrue(Main.checkTokens("5^5",tokens2));
		int[] tokens3 = {5,7,6};
		assertTrue(Main.checkTokens("(3)",tokens3));
		int[] tokens4 = {5,1,6};
		assertTrue(Main.checkTokens("(4)",tokens4));
	}
	@Test
	public void testSolution()
	{
		assertTrue(Main.compareAnswer("1+1", 2));
		assertTrue(Main.compareAnswer("(10*5^2)/2",125));
		assertTrue(Main.compareAnswer("10*5^2", 250));
		assertFalse(Main.compareAnswer("10*5^2", 251));
	}
	
	@Test
	public void testSetVariable()
	{
		assertTrue(Main.checkVariableValue("300", "m", 300));
		assertTrue(Main.checkVariableValue("-.00001", "m", -.00001));
		
		assertFalse(Main.checkVariableValue("-.00001", "thisNumber", .00001));
	}
	
	@Test
	public void testParserException() 
	{
	  exception.expect(ParserException.class);
	   Main.solve("h 21");
	   Main.solve("z jfjfjfj jfjfjfj");
	   Main.solve(".r 1");
	   Main.solve("z j12 222 2");
	   
	}
	
	@Test
	public void testEvaluationException() 
	{
	   exception.expect(EvaluationException.class);
	   Main.solve("1+r");
	   Main.solve("12+5+r");  
	}
}
