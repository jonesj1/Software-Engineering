import java.util.LinkedList;
import java.util.Scanner;


public class Main {


	static ExpressionNode expr;

	/**

	 * The main method to test the functionality of the parser

	 */

	public static void main(String[] args)

	{
		System.out.println("Enter an expression to evaluate");
		Scanner reader = new Scanner(System.in);
		String exprstr = reader.nextLine();

		if (args.length>0) exprstr = args[0];

		Parser parser = new Parser();

		try

		{

			expr = parser.parse(exprstr);

			expr.accept(new SetVariable("pi", Math.PI));
			

			System.out.println("The value of the expression is "+expr.getValue());
		}

		catch (ParserException e)

		{

			System.out.println(e.getMessage());

		}

		catch (EvaluationException e)

		{

			System.out.println(e.getMessage());

		}

	}
	
	//Returns the solution to the expression
	public static double solve(String expstr)
	{
		Parser parser = new Parser();
		expr = parser.parse(expstr);
		return expr.getValue();
	}
	
	//Makes sure the value of the variable that the user sets is what it is supposed to be
	public static boolean checkVariableValue(String expstr, String variable, double value)
	{
		Parser parser = new Parser();
		expr = parser.parse(expstr);
		expr.accept(new SetVariable(variable,value));
		if(expr.getValue() != value)
			return false;
		return true;
	}

	public static boolean compareAnswer(String expstr, double expectedSolution)
	{
		Parser parser = new Parser();
		expr = parser.parse(expstr);
		expr.accept(new SetVariable("pi", Math.PI));
		if(expr.getValue() != expectedSolution)
			return false;
		return true;
	}
	
	public static boolean compareNodeType(String expstr,int nodeType)
	{
		Parser parser = new Parser();
		expr = parser.parse(expstr);
		
		if(expr.getType() == nodeType)
			return true;
		return false;
	}
	
	

	public static boolean checkTokens(String expstr, int[] expectedTokenValues)
	{
		LinkedList<Token> tokens = new LinkedList<Token>();
		boolean flag = true;
		int i = 0;
		
		for(Token token: tokens)
		{
			if(token.token != expectedTokenValues[i])
			{
				
				flag = false;
			}
		}
		return flag;
	}
}
